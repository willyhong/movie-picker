var vue = new Vue({
 el: "#app",
 data: {
    gather: true,
    state: "Press the cards to start a game!",
    symbols: [
      {label: "spades",symbol: "♠" },
      {label: "hearts",symbol: "♥" },
      {label: "diamonds",symbol: "♦" },
      {label: "clubs",symbol: "♣" }
    ],
    cards: [
      {
        id: 1,label: "spades",open: false
      },
      {
        id: 2,label: "hearts", open: false
      },
      {
        id: 3,label: "clubs", open: false
      },
      {
        id: 4,label: "diamonds", open: false
      }
    ],
    
    question: null,
    mode: "",
    count: 0,
  },

 methods: {
  shuffle(){//洗牌
     let newOrder=[1,2,3,4].sort((a,b)=>Math.random()>0.5?1:-1)
     this.cards.forEach((card,cid)=>card.id=newOrder[cid])
    },
  turnAll(state){//把卡牌全部打開
   this.cards.forEach(card=>card.open=state)
  },
  startGame(){//1.清空array 2.選擇花色 3. 把牌蓋起來 4.把牌收起來
   this.mode=""
   this.question=this.symbols[parseInt(Math.random()*4)]
   this.turnAll(false)
   this.gather=true
   this.state="Ready.."
   setTimeout(()=>{//把牌散開
    this.gather=false
    this.state="Your mission is....."
   },1000)
   setTimeout(()=>{
        this.turnAll(true)
        this.state="Find "+this.question.label+this.question.symbol+ "!"
      },2000)
   setTimeout(()=>{
        this.turnAll(false)
        this.state="Get ready.."
      },4000)
   this.count=0//洗牌要先歸0
   setTimeout(()=>{//洗牌
        let startShuffle=()=>{
         this.shuffle()
         console.log("Shuffle!!"+this.count)
         if(this.count++<6){//洗牌少於6次
         setTimeout(startShuffle,300)
         }else{
          this.state="plz pick out "+this.question.label+this.question.symbol+ "!"
          this.mode = "answer"
         }
        }
        startShuffle()
      },6000)
  },
  getSymbol(label){ //花色判斷
   let result = this.symbols.find(s=>s.label==label)
   return result?result.symbol:label
  },
  getCard(label){
      return this.cards.find(card=>card.label==label)
    },
  openCard(card){
   if(this.mode=="answer"){//把卡片翻過來
    card.open =! card.open//原本是蓋起來
    if(card.label==this.question.label){
     this.state="Yes u got the  "+ this.question.label+this.question.symbol+ "!"
    }else{
          this.state="You lose!!!"
          setTimeout(()=>{
            this.getCard(this.question.label).open=true 
          },1000)
        }
    setTimeout(()=>{
     this.startGame()
    },3000)
   }else{
    this.startGame()
   }
  }
 },
 mounted(){
   // this.startGame()
  }
})